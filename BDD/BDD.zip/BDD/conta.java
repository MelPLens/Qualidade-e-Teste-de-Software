import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * Classe de definições de passos relacionados aos saques em contas.
 * Contém os passos do Cucumber para cenários envolvendo saques.
 */
public class conta {

    /**
     * Define um cliente especial com saldo negativo na conta.
     * @param arg1 o saldo negativo do cliente
     * @throws Throwable exceção pendente (ainda não implementada)
     */
    @Given("^Um cliente especial com saldo atual de -(\\d+) reais$")
    public void um_cliente_especial_com_saldo_atual_de_reais(int arg1) throws Throwable {
        throw new PendingException();
    }

    /**
     * Realiza a solicitação de um saque com um valor específico.
     * @param arg1 o valor do saque solicitado
     * @throws Throwable exceção pendente (ainda não implementada)
     */
    @When("^for solicitado um saque no valor de (\\d+) reais$")
    public void for_solicitado_um_saque_no_valor_de_reais(int arg1) throws Throwable {
        throw new PendingException();
    }

    /**
     * Verifica se o saque foi efetuado e atualiza o saldo da conta.
     * @param arg1 o saldo atualizado após o saque
     * @throws Throwable exceção pendente (ainda não implementada)
     */
    @Then("^deve efetuar o saque e atualizar o saldo da conta para -(\\d+) reais$")
    public void deve_efetuar_o_saque_e_atualizar_o_saldo_da_conta_para_reais(int arg1) throws Throwable {
        throw new PendingException();
    }

    /**
     * Realiza verificações adicionais após o saque.
     * @throws Throwable exceção pendente (ainda não implementada)
     */
    @Then("^check more outcomes$")
    public void check_more_outcomes() throws Throwable {
        throw new PendingException();
    }
}
