package Login;

import java.util.HashMap;
import java.util.Map;

/**
 * LoginScreen - Uma classe para gerenciar o login de usuários.
 *
 * @autor Mel Plens Angelis
 * @desde 2023-10-30
 * @versão 1.0
 */
public class LoginScreen {

    // Um mapa para armazenar os nomes de usuário e senhas correspondentes.
    private Map<String, String> userDatabase;

    /**
     * Construtor da classe LoginScreen.
     */
    public LoginScreen() {
       // Inicializa o mapa e adiciona alguns usuários de exemplo no banco de dados
       // HashMap.
        userDatabase = new HashMap<>();
        userDatabase.put("john", "password123");
        userDatabase.put("alice", "securepass");
    }

    /**
     * Tenta autenticar um usuário com um nome de usuário e senha fornecidos.
     *
     * @param username O nome de usuário a ser verificado.
     * @param password A senha a ser verificada.
     * @return true se a autenticação for bem-sucedida, caso contrário, false.
     */
    public boolean login(String username, String password) {
        if (userDatabase.containsKey(username)) {
            String storedPassword = userDatabase.get(username);
            if (storedPassword.equals(password)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Adiciona um novo usuário ao banco de dados.
     *
     * @param username O nome de usuário a ser adicionado.
     * @param password A senha associada ao nome de usuário.
     */
    public void addUser(String username, String password) {
        userDatabase.put(username, password);
    }
}
